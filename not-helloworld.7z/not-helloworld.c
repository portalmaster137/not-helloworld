#include <stdio.h>

int main()
{
    printf("NOT Hello World!\n");
    return 0;
}